# 三套框架实现

同一套原理（View Transitions + clip-path circle）在三个技术栈下的落地代码。

---

## 一、Vue 3 + Element Plus（原著版本）

> 来源：<https://www.jeremyjone.com/1071/>（2024-10-15，作者 jeremyjone）
> 依赖：`element-plus`、`@vueuse/core`

### hooks/useDark.ts

用 vueuse 的 `useColorMode` 管理模式，因此 `el-switch` 必须以**只读方式传值**，
在 `change` 事件里改 `mode`，否则会和 hook 内部状态打架。

```ts
import { useColorMode } from '@vueuse/core';
import { computed } from 'vue';

export const useDark = () => {
  const mode = useColorMode({
    emitAuto: true,
    storageKey: 'ACTIVE_COLOR_SCHEME',
    disableTransition: false,
    initialValue: 'light',
  });

  return {
    // 兼容 auto：跟随系统时读 system 值
    isDark: computed(
      () =>
        (mode.store.value === 'auto' ? mode.system.value : mode.store.value) === 'dark'
    ),
    mode,
  };
};
```

### XSwitchTheme.vue

```vue
<template>
  <el-switch
    class="XSwitchTheme"
    :model-value="isDark"
    @change="onChange"
    @click.capture="onClick"
  >
    <template #active-action>🌙</template>
    <template #inactive-action>🌞</template>
  </el-switch>
</template>

<script setup lang="ts">
import { useDark } from '@/hooks/useDark';
import { ref } from 'vue';

const { isDark, mode } = useDark();

// 记录点击位置作为圆形动画的圆心
const pos = ref({ x: 0, y: 0 });
function onClick(e: MouseEvent) {
  pos.value = { x: e.clientX, y: e.clientY };
}

function onChange(val: boolean) {
  const setTheme = () => {
    mode.value = val ? 'dark' : 'light';
  };

  const doAnimate = () => {
    const radius = Math.hypot(
      Math.max(pos.value.x, window.innerWidth - pos.value.x),
      Math.max(pos.value.y, window.innerHeight - pos.value.y)
    );

    const clipPath = [
      `circle(0px at ${pos.value.x}px ${pos.value.y}px)`,
      `circle(${radius}px at ${pos.value.x}px ${pos.value.y}px)`,
    ];

    document.documentElement.animate(
      // 按博客原实现：变暗时 old 从大圆收缩；变亮时 new 从小圆扩展。
      { clipPath: val ? clipPath.slice().reverse() : clipPath },
      {
        duration: 600,
        pseudoElement: val
          ? '::view-transition-old(root)'
          : '::view-transition-new(root)',
      }
    );
  };

  document.startViewTransition
    ? document.startViewTransition(setTheme).ready.then(doAnimate)
    : setTheme();
}
</script>

<style>
.XSwitchTheme {
  .el-switch__action {
    background-color: transparent;
  }
}

/* 重置默认过渡 */
::view-transition-new(root),
::view-transition-old(root) {
  animation: none;
  mix-blend-mode: normal;
}
/* 变暗时 old 亮色快照收缩；抬高它，避免被 new 暗色快照挡住 */
.dark::view-transition-old(root) {
  z-index: 9999999999;
}
</style>
```

**原著要点提醒**：`@click.capture` 是必须的 —— `el-switch` 内部的 change 时机在 click 之后，
用 capture 阶段先拿到坐标，才能保证 `onChange` 里读到的是本次点击的位置。

---

## 二、React + TDesign

TDesign 的暗色模式通过 `<html theme-mode="dark">` 属性启用（也可以在 `ConfigProvider` 上传
`themeMode`，但直接设属性对主题切换动画更友好：它不触发 React 重渲染）。

### useThemeToggle.ts

```ts
import { useCallback, useEffect, useRef, useState } from 'react';

export type ThemeMode = 'light' | 'dark';
const STORAGE_KEY = 'theme';

function readInitial(): ThemeMode {
  if (typeof window === 'undefined') return 'light';
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved === 'dark' || saved === 'light') return saved;
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

/** 把主题写到 <html>，供 TDesign 与自定义 CSS 共同消费 */
function paint(mode: ThemeMode) {
  const el = document.documentElement;
  el.classList.toggle('dark', mode === 'dark');
  el.setAttribute('theme-mode', mode); // TDesign 读这个属性
  el.dataset.theme = mode;
  el.style.colorScheme = mode;
}

export function useThemeToggle(duration = 600) {
  const [mode, setMode] = useState<ThemeMode>(readInitial);
  const switching = useRef(false);

  useEffect(() => {
    paint(mode);
    localStorage.setItem(STORAGE_KEY, mode);
  }, [mode]);

  const toggle = useCallback(
    (event?: React.MouseEvent) => {
      if (switching.current) return;

      const next: ThemeMode = mode === 'dark' ? 'light' : 'dark';
      const goingDark = next === 'dark';

      // detail === 0 表示键盘触发，没有真实坐标
      const isPointer = !!event && event.detail > 0;
      const x = isPointer ? event!.clientX : window.innerWidth - 48;
      const y = isPointer ? event!.clientY : 48;

      const setTheme = () => setMode(next);

      const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (typeof document.startViewTransition !== 'function' || reduce) {
        setTheme();
        return;
      }

      const radius = Math.hypot(
        Math.max(x, window.innerWidth - x),
        Math.max(y, window.innerHeight - y)
      );
      const clipPath = [
        `circle(0px at ${x}px ${y}px)`,
        `circle(${radius}px at ${x}px ${y}px)`,
      ];

      switching.current = true;
      const transition = document.startViewTransition(setTheme);

      transition.ready.then(() => {
        document.documentElement.animate(
          { clipPath: goingDark ? clipPath.slice().reverse() : clipPath },
          {
            duration,
            easing: 'ease-in-out',
            pseudoElement: goingDark
              ? '::view-transition-old(root)'
              : '::view-transition-new(root)',
          }
        );
      });

      transition.finished
        .catch(() => {})
        .then(() => {
          switching.current = false;
        });
    },
    [mode, duration]
  );

  return { mode, toggle };
}
```

> `setMode` 在 `startViewTransition` 的回调里触发 React 状态更新：DOM 变更可能不在回调同步阶段
> 完成，从而快照拍在更新之前。若遇到「快照是旧的」问题，把 `setMode` 换成
> `flushSync(() => setMode(next))`（`react-dom` 导出）即可强制同步提交。

### ThemeToggleButton.tsx

```tsx
import { useThemeToggle } from './useThemeToggle';

export function ThemeToggleButton() {
  const { mode, toggle } = useThemeToggle();

  return (
    <button
      className="theme-toggle"
      aria-label={mode === 'dark' ? '切换到亮色' : '切换到暗色'}
      onClick={toggle}
    >
      {mode === 'dark' ? '🌙' : '🌞'}
    </button>
  );
}
```

### TDesign 下的 CSS 需改一行

主题类名若只靠 `theme-mode` 属性，assets/theme-toggle.css 里的
`.dark::view-transition-old(root)` 要改写为：

```css
[theme-mode='dark']::view-transition-old(root) {
  z-index: 9999;
}
```

---

## 三、纯 HTML / 无框架

直接引入 `assets/theme-toggle.js` + `assets/theme-toggle.css`：

```html
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <title>主题切换示例</title>

    <!-- 首屏防闪烁：必须在样式表之前同步执行（详见 references/pitfalls.md 第 7 条） -->
    <script>
      (function () {
        try {
          var saved = localStorage.getItem('color-scheme-preference');
          var dark =
            saved === 'dark' ||
            ((!saved || saved === 'auto') &&
              matchMedia('(prefers-color-scheme: dark)').matches);
          if (dark) document.documentElement.classList.add('dark');
          document.documentElement.style.colorScheme = dark ? 'dark' : 'light';
        } catch (e) {}
      })();
    </script>

    <link rel="stylesheet" href="theme-toggle.css" />
  </head>
  <body>
    <button class="theme-toggle" onclick="ThemeToggle.toggle(event)">
      <span class="icon-light">🌞</span>
      <span class="icon-dark">🌙</span>
    </button>

    <script src="theme-toggle.js"></script>
  </body>
</html>
```

JS 里已包含：持久化、跟随系统、`prefers-reduced-motion` 降级、键盘触发兜底、连点互斥。
不需要再写任何业务逻辑。
