/*!
 * theme-toggle.js —— 从点击位置圆形扩散的亮/暗主题切换
 * 原理：View Transitions API 拍新旧快照 + clip-path circle 从点击位置擦换整页
 * 依赖：无（配合同目录 theme-toggle.css 使用）
 *
 * 用法：
 *   <link rel="stylesheet" href="theme-toggle.css">
 *   <script src="theme-toggle.js"></script>
 *   <button class="theme-toggle" onclick="ThemeToggle.toggle(event)">🌞/🌙</button>
 *
 * API：
 *   ThemeToggle.toggle(event)   在点击位置圆形切换，event 建议传（决定圆心）
 *   ThemeToggle.set('dark'|'light'|'auto')  直接设置，无动画
 *   ThemeToggle.get()           读取当前偏好（含 'auto'）
 *   ThemeToggle.current()       读取实际生效的配色（'light'|'dark'）
 */
(function (global) {
  'use strict';

  var STORAGE_KEY = 'color-scheme-preference'; // 'light' | 'dark' | 'auto'
  var DURATION = 600;
  var EASING = 'ease-in-out';

  var root = document.documentElement;
  var mqlDark = window.matchMedia('(prefers-color-scheme: dark)');
  var mqlReduce = window.matchMedia('(prefers-reduced-motion: reduce)');

  // 动画期间的互斥锁：防止连点导致快照堆叠、白屏
  var switching = false;

  /* ---------------- 持久化 ---------------- */

  function readStored() {
    try {
      return localStorage.getItem(STORAGE_KEY) || 'auto';
    } catch (e) {
      return 'auto';
    }
  }

  function writeStored(pref) {
    try {
      localStorage.setItem(STORAGE_KEY, pref);
    } catch (e) {
      /* 隐私模式等场景写入失败，忽略即可 */
    }
  }

  /* ---------------- 主题解析与绘制 ---------------- */

  // 'auto' 跟随系统，其余原样
  function resolve(pref) {
    if (pref === 'auto') return mqlDark.matches ? 'dark' : 'light';
    return pref === 'dark' ? 'dark' : 'light';
  }

  // 只改 DOM，不做动画 —— 同时作为 startViewTransition 的回调
  function paint(scheme) {
    root.classList.toggle('dark', scheme === 'dark'); // 供 CSS 选择器与 .dark::view-transition-old 使用
    root.setAttribute('theme-mode', scheme);          // TDesign 等库约定的属性
    root.dataset.theme = scheme;                      // 通用 data 属性，方便自定义 CSS
    root.style.colorScheme = scheme;                  // 让滚动条/表单控件/输入框跟着变
  }

  function currentScheme() {
    return root.classList.contains('dark') ? 'dark' : 'light';
  }

  /* ---------------- 核心：圆形扩散切换 ---------------- */

  function toggle(event) {
    if (switching) return; // 动画中忽略，避免快照错位

    var nextScheme = currentScheme() === 'dark' ? 'light' : 'dark';
    var goingDark = nextScheme === 'dark';

    // 1. 圆心：取点击位置。
    //    detail === 0 说明是键盘 Enter/Space 触发的 click，此时没有真实坐标，
    //    退化到视口右上角，否则圆心落在 (0,0) 会让动画从左上角莫名扩散。
    var isPointer = !!(event && event.detail > 0 &&
      typeof event.clientX === 'number' && typeof event.clientY === 'number');
    var x = isPointer ? event.clientX : window.innerWidth - 48;
    var y = isPointer ? event.clientY : 48;

    var setTheme = function () {
      paint(nextScheme);
      writeStored(nextScheme);
    };

    // 降级：不支持 API，或用户开启了「减少动效」→ 直接切换，功能不受影响
    if (typeof document.startViewTransition !== 'function' || mqlReduce.matches) {
      setTheme();
      return;
    }

    // 2. 半径：圆心到最远角的距离，保证圆最终能盖满整个视口
    var radius = Math.hypot(
      Math.max(x, window.innerWidth - x),
      Math.max(y, window.innerHeight - y)
    );

    var clipPath = [
      'circle(0px at ' + x + 'px ' + y + 'px)',
      'circle(' + radius + 'px at ' + x + 'px ' + y + 'px)'
    ];

    switching = true;

    try {
      var transition = document.startViewTransition(setTheme);

      transition.ready.then(function () {
        // 博客映射：变暗时旧亮色快照由大圆收缩，露出新暗色页面；
        //           变亮时新亮色快照由小圆扩展，覆盖旧暗色页面。
        root.animate(
          { clipPath: goingDark ? clipPath.slice().reverse() : clipPath },
          {
            duration: DURATION,
            easing: EASING,
            pseudoElement: goingDark
              ? '::view-transition-old(root)'
              : '::view-transition-new(root)'
          }
        );
      });

      transition.finished.catch(function () {}).then(function () {
        switching = false;
      });
    } catch (e) {
      // 极端情况下 API 抛错（如文档处于非活跃状态），保证状态能恢复
      switching = false;
      setTheme();
    }
  }

  /* ---------------- 直接设置（无动画） ---------------- */

  function setPref(pref) {
    var scheme = resolve(pref);
    paint(scheme);
    writeStored(pref);
    return scheme;
  }

  /* ---------------- 初始化 ---------------- */

  function bindSystemListener() {
    var handler = function () {
      // 仅当用户处于「跟随系统」时才响应系统切换
      if (readStored() === 'auto') paint(resolve('auto'));
    };
    if (typeof mqlDark.addEventListener === 'function') {
      mqlDark.addEventListener('change', handler);
    } else if (typeof mqlDark.addListener === 'function') {
      mqlDark.addListener(handler);
    }
  }

  function init() {
    paint(resolve(readStored()));
    bindSystemListener();
    return currentScheme();
  }

  // 立刻执行：documentElement 在脚本执行时一定存在，
  // 这样即使在 <head> 中引入也能尽早打上主题，减少首屏亮暗闪烁。
  init();

  global.ThemeToggle = {
    init: init,
    toggle: toggle,
    set: setPref,
    get: readStored,
    current: currentScheme,
    DURATION: DURATION
  };
})(typeof window !== 'undefined' ? window : this);
