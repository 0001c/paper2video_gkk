---
name: view-transition-theme-toggle
description: 用 View Transitions API 和 clip-path circle 实现以点击位置为圆心的整页亮暗主题圆形擦换，方向与层级参考 Element Plus 官网和 JeremyJone 博客示例。当用户要求实现这种圆形主题切换或修复方向/层级问题时使用；不用于普通颜色渐变或涟漪动画。覆盖 Vue 3、React 与原生 JavaScript。
metadata:
  short-description: "从点击位置开始的整页明暗圆形擦换，含多框架实现与兼容降级"
  agent_created: true
---

# 点击起点圆形擦换主题（View Transitions）

## 一句话原理

把「切换主题」交给浏览器的 **View Transitions API** 拍两张页面快照（旧/新），
再用 **`clip-path: circle()`** 对其中一层做圆形裁切。圆心取自**点击位置**，半径取到
**视口最远角**的距离，圆形边界从开关处向外擦过整页；反向切换时，另一层沿相反方向擦入。

不需要蒙版、不需要 canvas、不需要手写 `requestAnimationFrame`。整个动画是浏览器合成的。

## 何时用

- 用户想要 Element Plus 官网那种从开关位置开始、覆盖整页的圆形明暗擦换。
- 已有主题切换但过渡生硬（直接变色、闪烁），想升级成有方向的过渡动画。
- 想给「切换」这类整页状态变更加过渡（同理可扩展到切语言、切路由）。

不适用：只需一个 `transition: background-color .3s` 的简单变色（用 CSS 就够）；
或目标浏览器明确不支持 View Transitions 且不愿降级。

## 动图里要复现的视觉

- Element Plus 官网示例和博客演示的开关都在页面右上方；圆心跟随本次点击坐标，不能固定在视口中心或写死在右上角。
- 页面整体像被圆形边界擦换：圆外先显示目标主题，圆内保留原主题（或反之）；它不是扩散光环、涟漪、多层波纹，也不是只给按钮本身加动画。
- 变暗时深色背景从开关周围向外覆盖，变亮时亮色从开关周围向外覆盖；圆要越过最远角，避免角落露出旧主题。
- Element Plus 动图的暗色页面还带有组件插画的蓝色高亮/光晕。这属于目标页面的主题样式，不是圆形转场本身；复刻基础效果时不应额外给整个页面加蓝色发光。
- 两支动图都先停留在静态页面并移动指针，再触发转场。忽略指针移动、页面滚动等准备帧，只以点击后的主题擦换作为目标效果。

博客实现的层映射有明确方向：变暗时让 `::view-transition-old(root)` 从大圆收缩到 0，露出新暗色页面；变亮时让 `::view-transition-new(root)` 从 0 扩大到覆盖全屏。不要只记“暗色总是 new 扩散”这类层映射口诀；理解每张快照承载的主题，再按实际代码设置方向和层。

## 四步拆解

1. **起点**：点击事件的 `event.clientX / clientY`（不要用按钮中心，观感差一截）。
2. **半径**：取「到最远角的距离」，保证圆能盖满全屏。
3. **画圆**：`clip-path: circle(<r>px at <x>px <y>px)`。
4. **动起来**：`document.startViewTransition()` 包住改主题的代码，在 `.ready` 后对伪元素跑 `element.animate()`。

第 4 步是唯一「新」的部分，前三步都是普通的坐标与 CSS 计算。

## 最小可用实现（无框架，直接抄）

完整可直接引入的版本见 `assets/theme-toggle.js` + `assets/theme-toggle.css`，核心逻辑：

```ts
function toggle(event: MouseEvent) {
  const html = document.documentElement;
  const next = html.classList.contains('dark') ? 'light' : 'dark';

  // 1. 起点：点击位置；键盘触发时退化为视口右上角，避免 x/y 为 0 导致动画没有方向感
  const hasPointer = !!event && event.detail > 0;
  const x = hasPointer ? event.clientX : window.innerWidth - 40;
  const y = hasPointer ? event.clientY : 40;

  const setTheme = () => {
    html.classList.toggle('dark', next === 'dark');
    html.style.colorScheme = next;          // 让原生控件（滚动条/表单）跟着变
    localStorage.setItem('theme', next);
  };

  // 降级 / 无障碍：不支持 API 或用户要求减少动效，直接切换
  if (!document.startViewTransition || matchMedia('(prefers-reduced-motion: reduce)').matches) {
    return setTheme();
  }

  // 2. 半径：到最远角的距离（Math.hypot 求斜边）
  const radius = Math.hypot(
    Math.max(x, window.innerWidth - x),
    Math.max(y, window.innerHeight - y)
  );

  const clipPath = [
    `circle(0px at ${x}px ${y}px)`,
    `circle(${radius}px at ${x}px ${y}px)`,
  ];

  const goingDark = next === 'dark';

  // 4. 交给浏览器做过渡
  document.startViewTransition(setTheme).ready.then(() => {
    document.documentElement.animate(
      // 博客中的映射：变暗时收缩旧（亮色）快照；变亮时扩展新（亮色）快照。
      // 复制数组再 reverse，避免后续复用时把 clipPath 本身改乱。
      { clipPath: goingDark ? clipPath.slice().reverse() : clipPath },
      {
        duration: 600,
        easing: 'ease-in-out',
        // 关键：变暗作用于 old 层，变亮作用于 new 层
        pseudoElement: goingDark
          ? '::view-transition-old(root)'
          : '::view-transition-new(root)',
      }
    );
  });
}
```

配套 CSS 见下节「三个必踩的坑」第 1、2 条 —— **不加这两段 CSS，动画会基本看不见**。

## 三个必踩的坑（原文实测踩过）

### 1. 伪元素自带默认淡入淡出，必须重置

不重置的话，你写的 `clip-path` 动画会被默认的 cross-fade 盖住，看起来「动了但很糊、几乎看不出来」：

```css
::view-transition-old(root),
::view-transition-new(root) {
  animation: none;
  mix-blend-mode: normal;
}
```

### 2. 深色旧快照层级不对，方向动画看不见

`new` 层默认在 `old` 层之上。博客实现变暗时动画的是旧亮色层，让它从圆内收走，
露出新暗色层；暗色状态下要把 `old` 层抬高，否则圆形裁切会被新快照盖住：

```css
/* 注意选择器带 .dark：只有「当前是暗色」时才需要抬 z-index */
.dark::view-transition-old(root) {
  z-index: 9999;
}
```

踩坑点：**必须用能准确匹配深色状态的选择器**，博客用 `.dark`。若项目使用属性或其他类名，
按实际主题状态改选择器；不要无条件给 old 层加高层级。

### 3. `startViewTransition` 缺 TS 类型声明

TS 打包时常报「类型上不存在属性 startViewTransition」。项目里补一份 `d.ts`：

```ts
// env.d.ts / global.d.ts
interface ViewTransition {
  ready: Promise<void>;
  finished: Promise<void>;
  updateCallbackDone: Promise<void>;
  skipTransition(): void;
}
interface Document {
  startViewTransition?: (cb: () => void | Promise<void>) => ViewTransition;
}
```

用可选属性（`?`）写，正好和运行时 `document.startViewTransition ? ... : ...` 的降级判断对齐。

## 兼容性与降级

| 能力 | 支持情况 | 处理方式 |
| --- | --- | --- |
| `document.startViewTransition` | Chrome/Edge 111+、Safari 18+；Firefox 支持较晚 | 特性检测，不支持则直接切主题（无动画） |
| `pseudoElement` 动画作用于 `::view-transition-*` | 需要 View Transitions 支持 | 同上 |
| `clip-path: circle()` | 浏览器支持已很广 | 可放心使用 |

**降级必须是「无动画但功能正常」**，而不是「不切换」。所以永远保留
`document.startViewTransition ? A : setTheme()` 这条分支 —— 这也是原文写法里容易被优化掉、
但绝不能省的一行。

## 工程化补强（原文未覆盖，建议默认带上）

1. **首屏闪烁（FOUC）**：主题类名若在 JS 里设置，SSR/静态页会先渲染出亮色再跳暗色。
   应在 `<head>` 内联一小段同步脚本，在首次绘制前读 `localStorage` / `prefers-color-scheme` 并打上
   `class="dark"` 与 `color-scheme`。
2. **连点打断**：动画期间重复点击会产生快照堆叠、观感抖动。
   用 `transition.finished` 之后才允许下一次切换，或在切换中 `skipTransition()`。
3. **`prefers-reduced-motion`**：前庭敏感用户应直接跳过扩散动画。已在上面代码里处理。
4. **同步 `color-scheme`**：切主题时顺手设置 `html.style.colorScheme`，否则滚动条、表单控件、输入法候选框仍是旧主题色。
5. **键盘可达**：`event` 可能来自键盘（clientX/Y 为 0），要像示例那样给一个合理的兜底起点。
6. **滚动位置**：View Transitions 快照期间页面会短暂冻结。若是长页面，建议在切换前
   `window.scrollTo` 保证触发元素在视口内，或接受这一瞬间的冻结（实践中 600ms 内无感知）。

## 交付检查清单

- [ ] 支持 API 时：整页圆形擦换从点击位置开始并到达最远角；变暗动画 `old(root)` 大到小，变亮动画 `new(root)` 小到大（按博客实现）。
- [ ] 不支持 API 时：主题仍能切换，只是没有动画。
- [ ] `::view-transition-old/new(root)` 默认动画已重置，`mix-blend-mode: normal`。
- [ ] `.dark::view-transition-old(root)` 的 z-index 已加，且匹配项目的深色主题状态。
- [ ] 刷新后主题保持（localStorage），且首屏无亮暗闪烁。
- [ ] 开启系统「减少动效」后动画消失。
- [ ] 连点 5 次不出现快照错位/白屏。

## 资源索引

| 文件 | 何时读 |
| --- | --- |
| `assets/demo.html` | **先看这个** —— 可直接在浏览器打开的效果演示页，也是最小可用参考实现 |
| `assets/theme-toggle.js` | 无框架项目，直接引入即用（含持久化、降级、reduced-motion） |
| `assets/theme-toggle.css` | 与上面配套的伪元素重置与少量开关样式 |
| `references/adoption.md` | **改造已有项目时先读这个** —— 现状分类、前提条件、改动清单、验证项 |
| `references/frameworks.md` | Vue3 + Element Plus（原著版本）、React + TDesign、纯 HTML 的完整代码 |
| `references/pitfalls.md` | 现象 → 原因 → 修法的排查表，动画「没效果/方向反了/闪一下」时先看这个 |

## 移植到其他 Agent（如 Codex）

Codex 对 frontmatter 有**字段白名单**：只允许 `name` / `description` / `license` / `allowed-tools` / `metadata`。
本 skill 顶层的 `agent_created` 在 Codex 下非法，移植时必须收进 `metadata`：

```yaml
metadata:
  short-description: "从点击位置开始的整页明暗圆形擦换，含多框架实现与兼容降级"
  agent_created: true
```

- 安装位置：`$CODEX_HOME/skills/<skill-name>/`（默认 `~/.codex/skills/`），目录级扫描，**无需注册任何清单文件**。
- 可选：加 `agents/openai.yaml` 提供 UI 展示信息（`display_name` / `short_description` / `default_prompt` 等，
  字符串值需加引号；`default_prompt` 必须提到 `$skill-name`）。
- 校验：`python <codex>/skills/.system/skill-creator/scripts/quick_validate.py <skill-dir>`（需 PyYAML）。
- 安装后需**下一轮对话**才生效（skill 在会话启动时加载）。
